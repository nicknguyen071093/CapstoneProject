/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Thu Jul 30 23:15:25 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *lbFunction;
    QGroupBox *gbNotify;
    QLabel *lbNotify;
    QGroupBox *gbCountDownTime;
    QLabel *lbCountDownTime;
    QGroupBox *gbFrame;
    QPushButton *btnLearning;
    QPushButton *btnRecognition;
    QLabel *lbFrame;
    QPushButton *btnUp;
    QPushButton *btnDown;
    QGroupBox *gbRecognitionNotify;
    QLabel *lbRecognitionNotify;
    QGroupBox *gbRecognitionTimer;
    QLabel *lbRecognitionTimer;
    QGroupBox *gbRecognitionResult;
    QLabel *lbRecognitionResult;
    QGroupBox *gbRecognitionContent;
    QLabel *lbRecognitionContent;
    QGroupBox *gbTestingResult;
    QLabel *lbTestingResult;
    QGroupBox *gbLearningNotify;
    QLabel *lbLearningNotify;
    QGroupBox *gbListWord;
    QListWidget *lwWord;
    QLabel *lbLearningImage;
    QGroupBox *gbTutorial;
    QLabel *lbTutorialImage;
    QStatusBar *statusBar;
    QToolBar *mainToolBar;
    QMenuBar *menuBar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1280, 720);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        lbFunction = new QLabel(centralWidget);
        lbFunction->setObjectName(QString::fromUtf8("lbFunction"));
        lbFunction->setGeometry(QRect(6, -1, 1261, 61));
        QFont font;
        font.setPointSize(22);
        font.setBold(true);
        font.setWeight(75);
        lbFunction->setFont(font);
        lbFunction->setStyleSheet(QString::fromUtf8("QLabel { \n"
"color: #7b5701;\n"
" } "));
        lbFunction->setAlignment(Qt::AlignCenter);
        gbNotify = new QGroupBox(centralWidget);
        gbNotify->setObjectName(QString::fromUtf8("gbNotify"));
        gbNotify->setGeometry(QRect(50, 80, 591, 141));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        gbNotify->setFont(font1);
        gbNotify->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size:  25px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbNotify = new QLabel(gbNotify);
        lbNotify->setObjectName(QString::fromUtf8("lbNotify"));
        lbNotify->setGeometry(QRect(10, 40, 571, 91));
        QFont font2;
        font2.setPointSize(15);
        font2.setBold(true);
        font2.setWeight(75);
        lbNotify->setFont(font2);
        lbNotify->setWordWrap(true);
        gbCountDownTime = new QGroupBox(centralWidget);
        gbCountDownTime->setObjectName(QString::fromUtf8("gbCountDownTime"));
        gbCountDownTime->setGeometry(QRect(690, 80, 541, 141));
        gbCountDownTime->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbCountDownTime = new QLabel(gbCountDownTime);
        lbCountDownTime->setObjectName(QString::fromUtf8("lbCountDownTime"));
        lbCountDownTime->setGeometry(QRect(10, 40, 521, 91));
        QFont font3;
        font3.setPointSize(50);
        font3.setBold(true);
        font3.setWeight(75);
        lbCountDownTime->setFont(font3);
        lbCountDownTime->setAlignment(Qt::AlignCenter);
        gbFrame = new QGroupBox(centralWidget);
        gbFrame->setObjectName(QString::fromUtf8("gbFrame"));
        gbFrame->setGeometry(QRect(50, 270, 591, 371));
        gbFrame->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } \n"
"\n"
"\n"
"\n"
""));
        btnLearning = new QPushButton(gbFrame);
        btnLearning->setObjectName(QString::fromUtf8("btnLearning"));
        btnLearning->setGeometry(QRect(310, 90, 130, 50));
        QFont font4;
        font4.setPointSize(17);
        btnLearning->setFont(font4);
        btnLearning->setStyleSheet(QString::fromUtf8("#btnLearning {\n"
"background-color: white;\n"
"}"));
        btnRecognition = new QPushButton(gbFrame);
        btnRecognition->setObjectName(QString::fromUtf8("btnRecognition"));
        btnRecognition->setGeometry(QRect(160, 90, 130, 50));
        btnRecognition->setFont(font4);
        btnRecognition->setStyleSheet(QString::fromUtf8("#btnRecognition {\n"
"background-color: white;\n"
"}"));
        lbFrame = new QLabel(gbFrame);
        lbFrame->setObjectName(QString::fromUtf8("lbFrame"));
        lbFrame->setGeometry(QRect(140, 70, 320, 240));
        lbFrame->setCursor(QCursor(Qt::ArrowCursor));
        btnUp = new QPushButton(gbFrame);
        btnUp->setObjectName(QString::fromUtf8("btnUp"));
        btnUp->setGeometry(QRect(160, 90, 130, 50));
        QFont font5;
        font5.setPointSize(20);
        btnUp->setFont(font5);
        btnUp->setStyleSheet(QString::fromUtf8("#btnRecognition {\n"
"background-color: white;\n"
"}"));
        btnDown = new QPushButton(gbFrame);
        btnDown->setObjectName(QString::fromUtf8("btnDown"));
        btnDown->setGeometry(QRect(310, 90, 130, 50));
        btnDown->setFont(font5);
        btnDown->setStyleSheet(QString::fromUtf8("#btnLearning {\n"
"background-color: white;\n"
"}"));
        lbFrame->raise();
        btnLearning->raise();
        btnRecognition->raise();
        btnUp->raise();
        btnDown->raise();
        gbRecognitionNotify = new QGroupBox(centralWidget);
        gbRecognitionNotify->setObjectName(QString::fromUtf8("gbRecognitionNotify"));
        gbRecognitionNotify->setGeometry(QRect(50, 80, 591, 141));
        gbRecognitionNotify->setFont(font1);
        gbRecognitionNotify->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbRecognitionNotify = new QLabel(gbRecognitionNotify);
        lbRecognitionNotify->setObjectName(QString::fromUtf8("lbRecognitionNotify"));
        lbRecognitionNotify->setGeometry(QRect(10, 30, 561, 101));
        QFont font6;
        font6.setPointSize(20);
        font6.setBold(true);
        font6.setWeight(75);
        lbRecognitionNotify->setFont(font6);
        lbRecognitionNotify->setWordWrap(true);
        gbRecognitionTimer = new QGroupBox(centralWidget);
        gbRecognitionTimer->setObjectName(QString::fromUtf8("gbRecognitionTimer"));
        gbRecognitionTimer->setGeometry(QRect(690, 80, 541, 101));
        gbRecognitionTimer->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 25px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbRecognitionTimer = new QLabel(gbRecognitionTimer);
        lbRecognitionTimer->setObjectName(QString::fromUtf8("lbRecognitionTimer"));
        lbRecognitionTimer->setGeometry(QRect(10, 30, 521, 61));
        lbRecognitionTimer->setFont(font3);
        lbRecognitionTimer->setAlignment(Qt::AlignCenter);
        gbRecognitionResult = new QGroupBox(centralWidget);
        gbRecognitionResult->setObjectName(QString::fromUtf8("gbRecognitionResult"));
        gbRecognitionResult->setGeometry(QRect(690, 230, 541, 101));
        gbRecognitionResult->setFont(font1);
        gbRecognitionResult->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 25px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbRecognitionResult = new QLabel(gbRecognitionResult);
        lbRecognitionResult->setObjectName(QString::fromUtf8("lbRecognitionResult"));
        lbRecognitionResult->setGeometry(QRect(10, 30, 591, 61));
        QFont font7;
        font7.setPointSize(30);
        font7.setBold(true);
        font7.setWeight(75);
        lbRecognitionResult->setFont(font7);
        lbRecognitionResult->setAlignment(Qt::AlignCenter);
        lbRecognitionResult->setWordWrap(true);
        gbRecognitionContent = new QGroupBox(centralWidget);
        gbRecognitionContent->setObjectName(QString::fromUtf8("gbRecognitionContent"));
        gbRecognitionContent->setGeometry(QRect(690, 380, 541, 261));
        gbRecognitionContent->setFont(font1);
        gbRecognitionContent->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbRecognitionContent = new QLabel(gbRecognitionContent);
        lbRecognitionContent->setObjectName(QString::fromUtf8("lbRecognitionContent"));
        lbRecognitionContent->setGeometry(QRect(10, 50, 521, 191));
        lbRecognitionContent->setFont(font6);
        lbRecognitionContent->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        lbRecognitionContent->setWordWrap(true);
        gbTestingResult = new QGroupBox(centralWidget);
        gbTestingResult->setObjectName(QString::fromUtf8("gbTestingResult"));
        gbTestingResult->setGeometry(QRect(690, 270, 541, 141));
        gbTestingResult->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbTestingResult = new QLabel(gbTestingResult);
        lbTestingResult->setObjectName(QString::fromUtf8("lbTestingResult"));
        lbTestingResult->setGeometry(QRect(10, 40, 591, 91));
        lbTestingResult->setFont(font7);
        lbTestingResult->setStyleSheet(QString::fromUtf8("#lbTestingResult {\n"
"    font-weight: bold;\n"
"}"));
        lbTestingResult->setAlignment(Qt::AlignCenter);
        gbLearningNotify = new QGroupBox(centralWidget);
        gbLearningNotify->setObjectName(QString::fromUtf8("gbLearningNotify"));
        gbLearningNotify->setGeometry(QRect(50, 80, 591, 141));
        gbLearningNotify->setFont(font1);
        gbLearningNotify->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size:  30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbLearningNotify = new QLabel(gbLearningNotify);
        lbLearningNotify->setObjectName(QString::fromUtf8("lbLearningNotify"));
        lbLearningNotify->setGeometry(QRect(10, 40, 561, 91));
        lbLearningNotify->setFont(font6);
        lbLearningNotify->setWordWrap(true);
        gbListWord = new QGroupBox(centralWidget);
        gbListWord->setObjectName(QString::fromUtf8("gbListWord"));
        gbListWord->setGeometry(QRect(690, 270, 541, 371));
        gbListWord->setFont(font1);
        gbListWord->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lwWord = new QListWidget(gbListWord);
        lwWord->setObjectName(QString::fromUtf8("lwWord"));
        lwWord->setGeometry(QRect(20, 50, 201, 301));
        lwWord->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        lbLearningImage = new QLabel(gbListWord);
        lbLearningImage->setObjectName(QString::fromUtf8("lbLearningImage"));
        lbLearningImage->setGeometry(QRect(240, 50, 281, 301));
        gbTutorial = new QGroupBox(centralWidget);
        gbTutorial->setObjectName(QString::fromUtf8("gbTutorial"));
        gbTutorial->setGeometry(QRect(690, 270, 541, 371));
        gbTutorial->setFont(font1);
        gbTutorial->setStyleSheet(QString::fromUtf8("QGroupBox { \n"
"     border: 2px solid gray; \n"
"     border-radius: 3px; \n"
"    font-size: 30px;\n"
"    font-weight: bold;\n"
"color: #7b5701;\n"
" } "));
        lbTutorialImage = new QLabel(gbTutorial);
        lbTutorialImage->setObjectName(QString::fromUtf8("lbTutorialImage"));
        lbTutorialImage->setGeometry(QRect(20, 50, 501, 301));
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1280, 22));
        MainWindow->setMenuBar(menuBar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        lbFunction->setText(QApplication::translate("MainWindow", "Vietnamese Sign Language Recognition System", 0, QApplication::UnicodeUTF8));
        gbNotify->setTitle(QApplication::translate("MainWindow", "Th\303\264ng B\303\241o", 0, QApplication::UnicodeUTF8));
        lbNotify->setText(QString());
        gbCountDownTime->setTitle(QApplication::translate("MainWindow", "Th\341\273\235i Gian", 0, QApplication::UnicodeUTF8));
        lbCountDownTime->setText(QString());
        gbFrame->setTitle(QApplication::translate("MainWindow", "H\303\254nh \341\272\243nh b\303\240n tay", 0, QApplication::UnicodeUTF8));
        btnLearning->setText(QApplication::translate("MainWindow", "H\341\273\215c", 0, QApplication::UnicodeUTF8));
        btnRecognition->setText(QApplication::translate("MainWindow", "Nh\341\272\255n D\341\272\241ng", 0, QApplication::UnicodeUTF8));
        lbFrame->setText(QString());
        btnUp->setText(QApplication::translate("MainWindow", "L\303\252n", 0, QApplication::UnicodeUTF8));
        btnDown->setText(QApplication::translate("MainWindow", "Xu\341\273\221ng", 0, QApplication::UnicodeUTF8));
        gbRecognitionNotify->setTitle(QApplication::translate("MainWindow", "Th\303\264ng B\303\241o", 0, QApplication::UnicodeUTF8));
        lbRecognitionNotify->setText(QApplication::translate("MainWindow", "H\341\273\207 th\341\273\221ng s\341\272\275 l\306\260u l\341\272\241i k\341\272\277t qu\341\272\243 nh\341\272\255n d\341\272\241ng sau 3 gi\303\242y!", 0, QApplication::UnicodeUTF8));
        gbRecognitionTimer->setTitle(QApplication::translate("MainWindow", "Th\341\273\235i Gian", 0, QApplication::UnicodeUTF8));
        lbRecognitionTimer->setText(QString());
        gbRecognitionResult->setTitle(QApplication::translate("MainWindow", "K\341\272\277t qu\341\272\243 nh\341\272\255n d\341\272\241ng", 0, QApplication::UnicodeUTF8));
        lbRecognitionResult->setText(QString());
        gbRecognitionContent->setTitle(QApplication::translate("MainWindow", "N\341\273\231i dung to\303\240n b\341\273\231", 0, QApplication::UnicodeUTF8));
        lbRecognitionContent->setText(QString());
        gbTestingResult->setTitle(QApplication::translate("MainWindow", "K\341\272\277t qu\341\272\243 ki\341\273\203m tra", 0, QApplication::UnicodeUTF8));
        lbTestingResult->setText(QString());
        gbLearningNotify->setTitle(QApplication::translate("MainWindow", "Th\303\264ng B\303\241o", 0, QApplication::UnicodeUTF8));
        lbLearningNotify->setText(QApplication::translate("MainWindow", "H\303\243y \304\221\306\260a k\303\255 hi\341\273\207u trong h\306\260\341\273\233ng d\341\272\253n v\303\240o v\303\271ng m\305\251i t\303\252n l\303\252n xu\341\273\221ng \304\221\341\273\203 thay \304\221\341\273\225i t\341\273\253 \304\221\306\260\341\273\243c ch\341\273\215n!", 0, QApplication::UnicodeUTF8));
        gbListWord->setTitle(QApplication::translate("MainWindow", "B\341\272\243ng ng\303\264n ng\341\273\257 c\303\242m", 0, QApplication::UnicodeUTF8));
        lbLearningImage->setText(QString());
        gbTutorial->setTitle(QApplication::translate("MainWindow", "H\303\254nh \341\272\243nh h\306\260\341\273\233ng d\341\272\253n", 0, QApplication::UnicodeUTF8));
        lbTutorialImage->setText(QString());
        toolBar->setWindowTitle(QApplication::translate("MainWindow", "toolBar", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
