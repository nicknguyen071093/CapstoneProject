/****************************************************************************
** Meta object code from reading C++ file 'CroppingImage.h'
**
** Created: Thu Jul 30 23:40:49 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "CroppingImage.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CroppingImage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CroppingImage[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      11,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,   68,   70,   70, 0x05,
      71,   70,   70,   70, 0x05,
     104,   70,   70,   70, 0x05,
     134,   70,   70,   70, 0x05,
     168,   70,   70,   70, 0x05,
     212,   70,   70,   70, 0x05,
     253,   70,   70,   70, 0x05,
     297,   70,   70,   70, 0x05,
     332,   70,   70,   70, 0x05,
     369,   70,   70,   70, 0x05,
     399,   70,   70,   70, 0x05,

 // slots: signature, parameters, type, tag, flags
     429,   70,   70,   70, 0x0a,
     451,   68,   70,   70, 0x0a,
     479,   70,  498,   70, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_CroppingImage[] = {
    "CroppingImage\0"
    "sendSignalToChangeLabelTestingResult(QString,QString)\0"
    ",\0\0sendSignalSelectingRecognition()\0"
    "sendSignalSelectingLearning()\0"
    "sendSignalChangeToSelectingMode()\0"
    "sendSignalChangingRecognitionColor(QString)\0"
    "sendSignalChangingLearningColor(QString)\0"
    "sendSignalChangingRecognitionResult(double)\0"
    "sendSignalChangingUpColor(QString)\0"
    "sendSignalChangingDownColor(QString)\0"
    "sendSignalMovingToUpperWord()\0"
    "sendSignalMovingToLowerWord()\0"
    "changeToTestingMode()\0receiveBinaryImage(Mat,Mat)\0"
    "getTestingResult()\0bool\0"
};

void CroppingImage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        CroppingImage *_t = static_cast<CroppingImage *>(_o);
        switch (_id) {
        case 0: _t->sendSignalToChangeLabelTestingResult((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: _t->sendSignalSelectingRecognition(); break;
        case 2: _t->sendSignalSelectingLearning(); break;
        case 3: _t->sendSignalChangeToSelectingMode(); break;
        case 4: _t->sendSignalChangingRecognitionColor((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->sendSignalChangingLearningColor((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->sendSignalChangingRecognitionResult((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 7: _t->sendSignalChangingUpColor((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->sendSignalChangingDownColor((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->sendSignalMovingToUpperWord(); break;
        case 10: _t->sendSignalMovingToLowerWord(); break;
        case 11: _t->changeToTestingMode(); break;
        case 12: _t->receiveBinaryImage((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2]))); break;
        case 13: { bool _r = _t->getTestingResult();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CroppingImage::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CroppingImage::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_CroppingImage,
      qt_meta_data_CroppingImage, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CroppingImage::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CroppingImage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CroppingImage::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CroppingImage))
        return static_cast<void*>(const_cast< CroppingImage*>(this));
    return QThread::qt_metacast(_clname);
}

int CroppingImage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void CroppingImage::sendSignalToChangeLabelTestingResult(QString _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CroppingImage::sendSignalSelectingRecognition()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void CroppingImage::sendSignalSelectingLearning()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void CroppingImage::sendSignalChangeToSelectingMode()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void CroppingImage::sendSignalChangingRecognitionColor(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void CroppingImage::sendSignalChangingLearningColor(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void CroppingImage::sendSignalChangingRecognitionResult(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void CroppingImage::sendSignalChangingUpColor(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void CroppingImage::sendSignalChangingDownColor(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void CroppingImage::sendSignalMovingToUpperWord()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}

// SIGNAL 10
void CroppingImage::sendSignalMovingToLowerWord()
{
    QMetaObject::activate(this, &staticMetaObject, 10, 0);
}
QT_END_MOC_NAMESPACE
