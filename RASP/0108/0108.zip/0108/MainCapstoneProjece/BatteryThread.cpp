#include "BatteryThread.h"

BatteryThread::BatteryThread(QObject *parent) :
    QThread(parent)
{
    if (!bcm2835_init()) exit(0);
    bcm2835_gpio_fsel(PIN07,BCM2835_GPIO_FSEL_INPT);
    bcm2835_gpio_fsel(PIN11,BCM2835_GPIO_FSEL_INPT);
    bcm2835_gpio_fsel(PIN13,BCM2835_GPIO_FSEL_INPT);
    bcm2835_gpio_fsel(PIN15,BCM2835_GPIO_FSEL_INPT);
    STOP = false;
}

void BatteryThread::run() {
    while(true) {
        mutex.lock();
        if (STOP) {
            bcm2835_close();
            break;
        }
        mutex.unlock();
        int capacity = bcm2835_gpio_lev(PIN07) + bcm2835_gpio_lev(PIN11) + bcm2835_gpio_lev(PIN13) + bcm2835_gpio_lev(PIN15);
        emit sendSignalShowingBatteryCapacity(capacity);
        sleep(20);
    }
}
