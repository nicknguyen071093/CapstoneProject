#ifndef LOWBATTERYTIMER_H
#define LOWBATTERYTIMER_H

#include <QThread>
#include <QMutex>

class LowBatteryTimer : public QThread
{
    Q_OBJECT
public:
    explicit LowBatteryTimer(QObject *parent = 0);
    void enableWorking();

private:
    void run();
    QMutex mutex;
    bool isEnableWorking;
    bool STOP;

signals:
    void sendSignalCountDown(QString);
    void sendSignalCloseDialog();

public slots:
    
};

#endif // LOWBATTERYTIMER_H
