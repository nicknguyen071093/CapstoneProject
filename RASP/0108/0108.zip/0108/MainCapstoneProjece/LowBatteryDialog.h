#ifndef LOWBATTERYDIALOG_H
#define LOWBATTERYDIALOG_H

#include <QDialog>
#include "LowBatteryTimer.h"

namespace Ui {
class Dialog;
}

class LowBatteryDialog : public QDialog
{
    Q_OBJECT
public:
    explicit LowBatteryDialog(QWidget *parent = 0);
    ~LowBatteryDialog();
private:
    Ui::Dialog *ui;
signals:
    
public slots:
    void countDownTimer(QString);
};

#endif // LOWBATTERYDIALOG_H
