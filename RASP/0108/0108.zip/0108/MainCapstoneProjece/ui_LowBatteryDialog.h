/********************************************************************************
** Form generated from reading UI file 'LowBatteryDialog.ui'
**
** Created: Fri Jul 31 03:43:07 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOWBATTERYDIALOG_H
#define UI_LOWBATTERYDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *lbTitle;
    QLabel *lbNotify;
    QLabel *lbNotfiySecond;
    QLabel *lbCountDownTime;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(1000, 200);
        lbTitle = new QLabel(Dialog);
        lbTitle->setObjectName(QString::fromUtf8("lbTitle"));
        lbTitle->setGeometry(QRect(10, 10, 981, 41));
        QFont font;
        font.setPointSize(30);
        font.setBold(true);
        font.setWeight(75);
        lbTitle->setFont(font);
        lbTitle->setStyleSheet(QString::fromUtf8("QLabel { \n"
"color: #7b5701;\n"
" } "));
        lbTitle->setAlignment(Qt::AlignCenter);
        lbNotify = new QLabel(Dialog);
        lbNotify->setObjectName(QString::fromUtf8("lbNotify"));
        lbNotify->setGeometry(QRect(60, 60, 881, 31));
        QFont font1;
        font1.setPointSize(17);
        font1.setBold(true);
        font1.setWeight(75);
        lbNotify->setFont(font1);
        lbNotify->setAlignment(Qt::AlignCenter);
        lbNotfiySecond = new QLabel(Dialog);
        lbNotfiySecond->setObjectName(QString::fromUtf8("lbNotfiySecond"));
        lbNotfiySecond->setGeometry(QRect(60, 90, 881, 31));
        lbNotfiySecond->setFont(font1);
        lbNotfiySecond->setAlignment(Qt::AlignCenter);
        lbCountDownTime = new QLabel(Dialog);
        lbCountDownTime->setObjectName(QString::fromUtf8("lbCountDownTime"));
        lbCountDownTime->setGeometry(QRect(470, 130, 50, 50));
        QFont font2;
        font2.setPointSize(40);
        font2.setBold(true);
        font2.setWeight(75);
        lbCountDownTime->setFont(font2);
        lbCountDownTime->setAlignment(Qt::AlignCenter);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", 0, QApplication::UnicodeUTF8));
        lbTitle->setText(QApplication::translate("Dialog", "Pin Yeu", 0, QApplication::UnicodeUTF8));
        lbNotify->setText(QApplication::translate("Dialog", "Hien tai pin he thong da gan het. Nguoi dung vui long tat may va ket noi sac cho he thong.", 0, QApplication::UnicodeUTF8));
        lbNotfiySecond->setText(QApplication::translate("Dialog", "Thong bao se tu dong tat sau 5 giay.", 0, QApplication::UnicodeUTF8));
        lbCountDownTime->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOWBATTERYDIALOG_H
