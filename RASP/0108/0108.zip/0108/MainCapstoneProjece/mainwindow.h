#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "ImageTranslating.h"
#include "RetrievingFrame.h"
#include "ShowingImageThread.h"
#include "CroppingImage.h"

#include "TimerThread.h"
#include "RecognitionTimerThread.h"
#include "BatteryThread.h"
#include "LowBatteryTimer.h"

#include "Words.h"

#include "LowBatteryDialog.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    static int const EXIT_CODE_REBOOT = -123456789;
    ~MainWindow();

private slots:

    void onToShow(Mat);

    void changeLabelNotice(QString,QString);
    void changeLabelNotice(QString);
    void changeLabelTestingResult(QString,QString);

    void countDownRecognitionTimer(QString);
    void changeRecognitionResult(double);
    void updateRecognitionContent();

    void changeToSelectingFunction();
    void changeToRecognitionFunciton();
    void changeToLearningFunction();
    void onFinishingColorSubtraction(bool);

    void moveToUpperWord();
    void moveToLowerWord();
    void changeLearningResult(double);

    void showBatteryCapacity(int);
    void closeLowBatteryDialog();

protected:
    void closeEvent(QCloseEvent *event);

private:
    Ui::MainWindow *ui;

    LowBatteryDialog * lowBatteryDialog;

    TimerThread *timerThread;
    RecognitionTimerThread *recognitionTimerThread;

    RetrievingFrame *retrievingFrameThread;
    ShowingImageThread *showingImageThread;
    CroppingImage *croppingThread;

    BatteryThread *batteryThread;

    LowBatteryTimer *lowBatteryTimer;

    QString recognitionContent;

    Words *words;

    QPixmap framePixmap;
    QPixmap learningImagePixmap;

    void startThreads();

    void initiateSelectingFunctionInterface();
    void initiateRecognitionInterface();
    void initiateLearningInterface();
    void initiateColorSubtractionInterface();

    void changeImageByWordID(int);

};

#endif // MAINWINDOW_H
