#include "Speech.h"

Speech::Speech()
{
    espeak_AUDIO_OUTPUT output = AUDIO_OUTPUT_PLAYBACK;
    char *path = NULL;
    espeak_Initialize(output, bufferLength, path, options);
    espeak_SetParameter(espeakVOLUME,200,0);
    espeak_SetParameter(espeakRATE,140,0);
    espeak_SetParameter(espeakPITCH,75,0);
    espeak_SetParameter(espeakRANGE,50,0);
    espeak_VOICE *spec = (espeak_VOICE*) malloc(sizeof(espeak_VOICE));
    spec->name = "vie";
    spec->languages = "vi";
    spec->identifier = "vi";
    spec->gender = 1;
    spec->age =20;
    spec->variant = 0;
    espeak_SetVoiceByProperties(spec);
}

void Speech::speak(QString s) {
    espeak_POSITION_TYPE position_type;
    QByteArray ba = s.toLatin1();
    const char *str = ba.data();
    void* user_data;
    unsigned int size ,position = 0, end_position = 0, flags=espeakCHARS_AUTO, *unique_identifier;
    size = strlen(str)+1;
    espeak_Synth( str, size, position, position_type, end_position, flags,
                  unique_identifier, user_data );
    espeak_Synchronize( );
    espeak_Terminate();
}
