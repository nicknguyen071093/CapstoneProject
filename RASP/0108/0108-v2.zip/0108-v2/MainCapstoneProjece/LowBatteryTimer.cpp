#include "LowBatteryTimer.h"

LowBatteryTimer::LowBatteryTimer(QObject *parent) :
    QThread(parent)
{
    STOP = false;
    isEnableWorking = false;
}

void LowBatteryTimer::run() {
    while(true) {
        mutex.lock();
        if (STOP) break;
        mutex.unlock();
        if (isEnableWorking) {
            emit sendSignalCountDown("5");
            sleep(1);
            emit sendSignalCountDown("4");
            sleep(1);
            emit sendSignalCountDown("3");
            sleep(1);
            emit sendSignalCountDown("2");
            sleep(1);
            emit sendSignalCountDown("1");
            sleep(1);
            emit sendSignalCloseDialog();
            isEnableWorking = false;
        }
    }
}

void LowBatteryTimer::enableWorking() {
    isEnableWorking = true;
}
