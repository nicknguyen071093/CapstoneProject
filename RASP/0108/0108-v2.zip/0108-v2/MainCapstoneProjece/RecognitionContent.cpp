#include "RecognitionContent.h"

RecognitionContent::RecognitionContent()
{
    content = "";
    previousWord = "";
}

QString RecognitionContent::updateContent(QString newWord) {
    int lastIndex = content.size() -1 ;
    if(newWord.compare("MU", Qt::CaseInsensitive)){
        if(previousWord.compare("a",Qt::CaseInsensitive) == 0) {
            content = content.replace(lastIndex,1,"â");
        } else if(previousWord.compare("e",Qt::CaseInsensitive) == 0){
            content = content.replace(lastIndex,1,"ê");
        } else if(previousWord.compare("o",Qt::CaseInsensitive) == 0){
            content = content.replace(lastIndex,1,"ô");
        }
    } else if(newWord.compare("RAU", Qt::CaseInsensitive)){
        if(previousWord.compare("o",Qt::CaseInsensitive) == 0){
            content = content.replace(lastIndex,1,"ơ");
        } else if (previousWord.compare("u",Qt::CaseInsensitive) == 0) {
            content = content.replace(lastIndex,1,"ơ");
        }
    } else if (newWord.compare("space", Qt::CaseInsensitive)){
        content = content.append(" ");
    }
    previousWord = newWord;
    return content;
}

void RecognitionContent::clear() {
    content = "";
}
