#ifndef SPEECH_H
#define SPEECH_H

#include <QString>
#include <speak_lib.h>

class Speech
{
public:
    Speech();
    void speak(QString);

private:
    const static int bufferLength = 500;
    const static int options = 0;
};

#endif // SPEECH_H
