#ifndef RECOGNITIONCONTENT_H
#define RECOGNITIONCONTENT_H


#include <QString>
class RecognitionContent
{
public:
    RecognitionContent();
    // update recognition content and return new content
    QString updateContent(QString);
    void clear();

private:
    QString content;
    QString previousWord;
};

#endif // RECOGNITIONCONTENT_H
