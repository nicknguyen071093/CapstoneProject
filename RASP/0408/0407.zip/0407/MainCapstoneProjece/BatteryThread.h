#ifndef BATTERYTHREAD_H
#define BATTERYTHREAD_H

#include <QThread>
#include <QMutex>
#include <bcm2835.h>

#define PIN07 RPI_V2_GPIO_P1_07
#define PIN11 RPI_V2_GPIO_P1_11
#define PIN13 RPI_V2_GPIO_P1_13
#define PIN15 RPI_V2_GPIO_P1_15

class BatteryThread : public QThread
{
    Q_OBJECT
public:
    explicit BatteryThread(QObject *parent = 0);
    bool STOP;
private:
    void run();
    QMutex mutex;

signals:
    void sendSignalShowingBatteryCapacity(int);
public slots:
    
};

#endif // BATTERYTHREAD_H
