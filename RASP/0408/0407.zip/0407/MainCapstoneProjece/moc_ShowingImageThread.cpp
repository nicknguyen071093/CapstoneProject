/****************************************************************************
** Meta object code from reading C++ file 'ShowingImageThread.h'
**
** Created: Sat Aug 1 04:01:17 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "ShowingImageThread.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ShowingImageThread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ShowingImageThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      19,   31,   31,   31, 0x05,
      32,   57,   31,   31, 0x05,
      59,   31,   31,   31, 0x05,

 // slots: signature, parameters, type, tag, flags
      87,   31,   31,   31, 0x0a,
     108,   31,   31,   31, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ShowingImageThread[] = {
    "ShowingImageThread\0toShow(Mat)\0\0"
    "sendImageToCrop(Mat,Mat)\0,\0"
    "sendSignalEnableCountDown()\0"
    "onChangingImage(Mat)\0moveToHandDetectionMode()\0"
};

void ShowingImageThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ShowingImageThread *_t = static_cast<ShowingImageThread *>(_o);
        switch (_id) {
        case 0: _t->toShow((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 1: _t->sendImageToCrop((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2]))); break;
        case 2: _t->sendSignalEnableCountDown(); break;
        case 3: _t->onChangingImage((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 4: _t->moveToHandDetectionMode(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ShowingImageThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ShowingImageThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_ShowingImageThread,
      qt_meta_data_ShowingImageThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ShowingImageThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ShowingImageThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ShowingImageThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ShowingImageThread))
        return static_cast<void*>(const_cast< ShowingImageThread*>(this));
    return QThread::qt_metacast(_clname);
}

int ShowingImageThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void ShowingImageThread::toShow(Mat _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ShowingImageThread::sendImageToCrop(Mat _t1, Mat _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ShowingImageThread::sendSignalEnableCountDown()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
QT_END_MOC_NAMESPACE
