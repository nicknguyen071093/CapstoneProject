#include "LowBatteryDialog.h"
#include "ui_LowBatteryDialog.h"

LowBatteryDialog::LowBatteryDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

LowBatteryDialog::~LowBatteryDialog()
{
    delete ui;
}

void LowBatteryDialog::countDownTimer(QString time) {
    ui->lbCountDownTime->setText(time);
}
