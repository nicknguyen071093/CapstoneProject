#include "RecognitionContent.h"
#include "iostream"

using namespace std;

RecognitionContent::RecognitionContent()
{
    content = "";
    previousWord = "";
}

QString RecognitionContent::updateContent(QString newWord) {
    int lastIndex = content.size() -1 ;
    if(newWord.compare("MU", Qt::CaseInsensitive) == 0){
        if(previousWord.compare("a",Qt::CaseInsensitive) == 0) {
            content = content.replace(lastIndex,1,"â");
        } else if(previousWord.compare("e",Qt::CaseInsensitive) == 0){
            content = content.replace(lastIndex,1,"ê");
        } else if(previousWord.compare("o",Qt::CaseInsensitive) == 0){
            content = content.replace(lastIndex,1,"ô");
        }
    } else if(newWord.compare("RAU", Qt::CaseInsensitive) == 0){
        if(previousWord.compare("o",Qt::CaseInsensitive) == 0){
            content = content.replace(lastIndex,1,"ơ");
        } else if (previousWord.compare("u",Qt::CaseInsensitive) == 0) {
            content = content.replace(lastIndex,1,"ơ");
        }
    } else if (newWord.compare("space", Qt::CaseInsensitive) == 0){
        content = content.append(" ");
    } else {
        content = content.append(" " + newWord);
    }
    previousWord = newWord;
    return content;
}

void RecognitionContent::clear() {
    content = "";
}
