/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Sat Aug 1 04:01:03 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   25,   25,   25, 0x08,
      26,   61,   25,   25, 0x08,
      63,   25,   25,   25, 0x08,
      90,   61,   25,   25, 0x08,
     132,   25,   25,   25, 0x08,
     167,   25,   25,   25, 0x08,
     199,   25,   25,   25, 0x08,
     226,   25,   25,   25, 0x08,
     254,   25,   25,   25, 0x08,
     284,   25,   25,   25, 0x08,
     311,   25,   25,   25, 0x08,
     345,   25,   25,   25, 0x08,
     363,   25,   25,   25, 0x08,
     381,   25,   25,   25, 0x08,
     410,   25,   25,   25, 0x08,
     435,   25,   25,   25, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0onToShow(Mat)\0\0"
    "changeLabelNotice(QString,QString)\0,\0"
    "changeLabelNotice(QString)\0"
    "changeLabelTestingResult(QString,QString)\0"
    "countDownRecognitionTimer(QString)\0"
    "changeRecognitionResult(double)\0"
    "updateRecognitionContent()\0"
    "changeToSelectingFunction()\0"
    "changeToRecognitionFunciton()\0"
    "changeToLearningFunction()\0"
    "onFinishingColorSubtraction(bool)\0"
    "moveToUpperWord()\0moveToLowerWord()\0"
    "changeLearningResult(double)\0"
    "showBatteryCapacity(int)\0"
    "closeLowBatteryDialog()\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->onToShow((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 1: _t->changeLabelNotice((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->changeLabelNotice((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->changeLabelTestingResult((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 4: _t->countDownRecognitionTimer((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->changeRecognitionResult((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 6: _t->updateRecognitionContent(); break;
        case 7: _t->changeToSelectingFunction(); break;
        case 8: _t->changeToRecognitionFunciton(); break;
        case 9: _t->changeToLearningFunction(); break;
        case 10: _t->onFinishingColorSubtraction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->moveToUpperWord(); break;
        case 12: _t->moveToLowerWord(); break;
        case 13: _t->changeLearningResult((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 14: _t->showBatteryCapacity((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->closeLowBatteryDialog(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
