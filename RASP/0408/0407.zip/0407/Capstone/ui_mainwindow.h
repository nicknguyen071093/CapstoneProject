/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Wed Jul 29 00:52:42 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *lbFrame;
    QLabel *lbSubtractedHand;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_5;
    QLabel *lbWarning;
    QLineEdit *txtType;
    QPushButton *btnTakepic;
    QLabel *lbResult;
    QLabel *imgBin;
    QLabel *imgInner;
    QLabel *imgXuong;
    QLineEdit *txtName;
    QPushButton *pushButton_6;
    QLabel *lbThongbao;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(633, 538);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        lbFrame = new QLabel(centralWidget);
        lbFrame->setObjectName(QString::fromUtf8("lbFrame"));
        lbFrame->setGeometry(QRect(20, 10, 320, 240));
        lbSubtractedHand = new QLabel(centralWidget);
        lbSubtractedHand->setObjectName(QString::fromUtf8("lbSubtractedHand"));
        lbSubtractedHand->setGeometry(QRect(360, 10, 100, 100));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 360, 383, 68));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton_5 = new QPushButton(layoutWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        horizontalLayout->addWidget(pushButton_5);


        horizontalLayout_3->addLayout(horizontalLayout);


        verticalLayout->addLayout(horizontalLayout_3);

        lbWarning = new QLabel(centralWidget);
        lbWarning->setObjectName(QString::fromUtf8("lbWarning"));
        lbWarning->setGeometry(QRect(360, 200, 171, 41));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lbWarning->sizePolicy().hasHeightForWidth());
        lbWarning->setSizePolicy(sizePolicy);
        lbWarning->setText(QString::fromUtf8("Warning"));
        lbWarning->setScaledContents(false);
        lbWarning->setWordWrap(true);
        txtType = new QLineEdit(centralWidget);
        txtType->setObjectName(QString::fromUtf8("txtType"));
        txtType->setGeometry(QRect(420, 400, 201, 27));
        btnTakepic = new QPushButton(centralWidget);
        btnTakepic->setObjectName(QString::fromUtf8("btnTakepic"));
        btnTakepic->setGeometry(QRect(20, 440, 601, 27));
        lbResult = new QLabel(centralWidget);
        lbResult->setObjectName(QString::fromUtf8("lbResult"));
        lbResult->setGeometry(QRect(360, 230, 181, 41));
        QFont font;
        font.setPointSize(20);
        lbResult->setFont(font);
        imgBin = new QLabel(centralWidget);
        imgBin->setObjectName(QString::fromUtf8("imgBin"));
        imgBin->setGeometry(QRect(500, 10, 96, 96));
        imgInner = new QLabel(centralWidget);
        imgInner->setObjectName(QString::fromUtf8("imgInner"));
        imgInner->setGeometry(QRect(360, 120, 96, 96));
        imgXuong = new QLabel(centralWidget);
        imgXuong->setObjectName(QString::fromUtf8("imgXuong"));
        imgXuong->setGeometry(QRect(490, 120, 96, 96));
        txtName = new QLineEdit(centralWidget);
        txtName->setObjectName(QString::fromUtf8("txtName"));
        txtName->setGeometry(QRect(420, 370, 101, 27));
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(530, 370, 99, 27));
        lbThongbao = new QLabel(centralWidget);
        lbThongbao->setObjectName(QString::fromUtf8("lbThongbao"));
        lbThongbao->setGeometry(QRect(20, 330, 591, 17));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 633, 25));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        lbFrame->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        lbSubtractedHand->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("MainWindow", "Restart", 0, QApplication::UnicodeUTF8));
        btnTakepic->setText(QApplication::translate("MainWindow", "Takepic", 0, QApplication::UnicodeUTF8));
        lbResult->setText(QApplication::translate("MainWindow", "K\341\272\277t Qu\341\272\243:", 0, QApplication::UnicodeUTF8));
        imgBin->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        imgInner->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        imgXuong->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("MainWindow", "Open", 0, QApplication::UnicodeUTF8));
        lbThongbao->setText(QApplication::translate("MainWindow", "Th\303\264ng B\303\241o:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
