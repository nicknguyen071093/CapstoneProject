#ifndef SHOWINGIMAGETHREAD_H
#define SHOWINGIMAGETHREAD_H

#include <QThread>
#include <QMutex>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>

using namespace cv;
using namespace  std;

class ShowingImageThread : public QThread
{
    Q_OBJECT
public:
    explicit ShowingImageThread(QObject *parent = 0);
    bool STOP;

    void setToDefaults();

private:
    void run();
    QMutex mutex;
    // Mode that presamples background
    const static  int BACKGROUND_MODE = 0;
    // Mode that stores background features
    const static int GETTING_BACKGROUND_MODE = 1;
    // Mode that shows hand
    const static int HAND_DETECTION_MODE = 2;
    // check whether to execute
    bool enableToShow;
    // frame is received from camera, image after bluring, lab Image, image is shown
    Mat frame, blurMat, labMat, showMat, binMat;
    // current mode
    int mode;
    // width of image
    const static int IMAGE_COLS = 320;
    // height of image
    const static int IMAGE_ROWS = 240;
    // length of square to ressample background
    const static int SQUARE_LENGTH = IMAGE_ROWS / 20;
    //
    Mat element;
    // check whether value of pixel is in background range
    bool isInRange;
    // values of a pixel in lab image
    double valueLight, valueWarn, valueCool;
    // boundary values
    const static double lightRange = 60;
    const static double warnRange = 5;
    const static  double coolRange = 5;

    // vector stores value of pixel
    Vec3b intensityFrame;
    // Color red
    Scalar red;
    // Color White
    Scalar white;
    // Color Black
    Scalar black;
    // number of background's features
    const static int SAMPLE_BACK_NUM = 12;
    // array to store the position of the background features
    Point sampleBackPoints[SAMPLE_BACK_NUM][2];
    // to store lower value of range of a specific sample
    Scalar lowerBoundArray[320][240];
    // to store upper value of range of a specific sample
    Scalar upperBoundArray[320][240];
    // initiate background points
    void initBackPoints();
    // Draw specific feature points of background.
    Mat preSampleBack(Mat);

signals:
    void toShow(Mat);
    void sendImageToCrop(Mat,Mat);
    void sendSignalEnableCountDown();

public slots:
    void onChangingImage(Mat);
    void moveToHandDetectionMode();
};

#endif // SHOWINGIMAGETHREAD_H
