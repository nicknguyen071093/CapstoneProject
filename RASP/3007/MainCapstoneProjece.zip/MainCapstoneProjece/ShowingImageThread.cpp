#include "ShowingImageThread.h"


ShowingImageThread::ShowingImageThread(QObject *parent) :
    QThread(parent)
{
    STOP = false;
    enableToShow = false;
    //    isGettingFirstFinished = false;
    mode = BACKGROUND_MODE;
    red = Scalar(0,0,255);
    white = Scalar(255,255,255);
    black = Scalar(0,0,0);
    element = getStructuringElement(MORPH_ELLIPSE, Size( 2*3 + 1, 2*3 + 1 ), Point( 3, 3 ));
    binMat = Mat(240,320,CV_8UC1);
    showMat = Mat(240,320,CV_8UC3);
    initBackPoints();
}

void ShowingImageThread::run() {
//    vector<int> compression_params;
//    compression_params.push_back(CV_IMWRITE_JPEG_QUALITY);
//    compression_params.push_back(100);
    while(true) {
        mutex.lock();
        if(this->STOP) break;
        mutex.unlock();
        if (enableToShow) {
            flip(frame,frame,1);
            if (mode == HAND_DETECTION_MODE) {
                binMat.setTo(black);
                showMat.setTo(black);
                GaussianBlur(frame, blurMat, Size(9, 9), 4);
                cvtColor(blurMat, labMat, COLOR_BGR2Lab);
                for (int i = 0; i < IMAGE_COLS; i++) {
                    for (int j = 0; j < IMAGE_ROWS; j++) {
                        isInRange= false;
                        intensityFrame = labMat.at<Vec3b>(j,i);
                        valueLight =(double) intensityFrame.val[0];
                        valueWarn =(double) intensityFrame.val[1];
                        valueCool =(double) intensityFrame.val[2];
                        if (valueLight >= lowerBoundArray[i][j].val[0] && valueLight <= upperBoundArray[i][j].val[0]) {
                            if (valueWarn >= lowerBoundArray[i][j].val[1] && valueWarn <= upperBoundArray[i][j].val[1]) {
                                if (valueCool >= lowerBoundArray[i][j].val[2] && valueCool <= upperBoundArray[i][j].val[2]) {
                                    isInRange= true;
                                }
                            }
                        }
                        if (!isInRange) {
                            if (valueLight >= 60 && valueLight <= 160 && valueWarn >= 112 && valueWarn <= 132 && valueCool >= 97 && valueCool <= 117) {

                            } else {
                                binMat.at<unsigned char>(j,i) = 255;
                            }
                        }
                    }
                }
                /// Apply the specified morphology operation
                morphologyEx(binMat, binMat, CV_MOP_OPEN, element);
                emit sendImageToCrop(frame.clone(),binMat.clone());
                frame.copyTo(showMat,binMat);
            } else if (mode == GETTING_BACKGROUND_MODE) {
                GaussianBlur(frame, blurMat, Size(9, 9), 4);
                cvtColor(blurMat, labMat, COLOR_BGR2Lab);
                double valueLight, valueWarn, valueCool;
                Vec3b intensity;
                for (int i = 0; i < IMAGE_COLS; i++) {
                    for (int j = 0; j < IMAGE_ROWS; j++) {
                        intensity = labMat.at<Vec3b>(j,i);
                        valueLight =(double) intensity.val[0];
                        valueWarn =(double) intensity.val[1];
                        valueCool =(double) intensity.val[2];
                        if (valueLight - lightRange < 0) {
                            lowerBoundArray[i][j].val[0] = 0;
                        } else {
                            lowerBoundArray[i][j].val[0] = valueLight - lightRange;
                        }
                        if (valueLight + lightRange > 255) {
                            upperBoundArray[i][j].val[0] = 255;
                        } else {
                            upperBoundArray[i][j].val[0] =  valueLight + lightRange;
                        }
                        //            cout << "light:" << valueLight << " uper:" << upperBound[i][j].val[0] << " lower:" << lowerBound[i][j].val[0] << endl;
                        if (valueWarn - warnRange < 0) {
                            lowerBoundArray[i][j].val[1] = 0;
                        } else {
                            lowerBoundArray[i][j].val[1] = valueWarn - warnRange;
                        }
                        if (valueWarn + warnRange > 255) {
                            upperBoundArray[i][j].val[1] = 255;
                        } else {
                            upperBoundArray[i][j].val[1] =  valueWarn + warnRange;
                        }

                        if (valueCool - coolRange < 0) {
                            lowerBoundArray[i][j].val[2] = 0;
                        } else {
                            lowerBoundArray[i][j].val[2] = valueCool - coolRange;
                        }
                        if (valueCool + coolRange > 255) {
                            upperBoundArray[i][j].val[2] = 255;
                        } else {
                            upperBoundArray[i][j].val[2] =  valueCool + coolRange;
                        }
                    }
                }
                mode = HAND_DETECTION_MODE;
                emit sendSignalEnableCountDown();
            }  else if (mode == BACKGROUND_MODE) {
                showMat = preSampleBack(frame.clone());
                //                imwrite("../xulyanh/sample-background.jpg",showMat);
            }
            emit (toShow(showMat.clone()));
            enableToShow = false;
        }
    }
}

Mat ShowingImageThread::preSampleBack(Mat img) {
    for (int i = 0; i < SAMPLE_BACK_NUM; i++) {
        rectangle(img, sampleBackPoints[i][0], sampleBackPoints[i][1], red,
                1);
    }
    return img;
}

void ShowingImageThread::setToDefaults() {
    mode = BACKGROUND_MODE;
    enableToShow = false;
}


void ShowingImageThread::onChangingImage(Mat binary) {
    if (!enableToShow) {
        mutex.lock();
        frame = binary;
        enableToShow = true;
        mutex.unlock();
    }
}

void ShowingImageThread::moveToHandDetectionMode() {
    mutex.lock();
    this->mode = GETTING_BACKGROUND_MODE;
    mutex.unlock();
}

void ShowingImageThread::initBackPoints() {
    sampleBackPoints[0][0].x = IMAGE_COLS / 9;
    sampleBackPoints[0][0].y = IMAGE_ROWS / 7;
    sampleBackPoints[0][1].x = IMAGE_COLS / 9 + SQUARE_LENGTH;
    sampleBackPoints[0][1].y = IMAGE_ROWS / 7 + SQUARE_LENGTH;
    sampleBackPoints[1][0].x = IMAGE_COLS / 3;
    sampleBackPoints[1][0].y = IMAGE_ROWS / 7;
    sampleBackPoints[1][1].x = IMAGE_COLS / 3 + SQUARE_LENGTH;
    sampleBackPoints[1][1].y = IMAGE_ROWS / 7 + SQUARE_LENGTH;
    sampleBackPoints[2][0].x = IMAGE_COLS / 1.7;
    sampleBackPoints[2][0].y = IMAGE_ROWS / 7 ;
    sampleBackPoints[2][1].x = IMAGE_COLS / 1.7 + SQUARE_LENGTH;
    sampleBackPoints[2][1].y = IMAGE_ROWS / 7  + SQUARE_LENGTH;
    sampleBackPoints[3][0].x = IMAGE_COLS / 9 * 7.5;
    sampleBackPoints[3][0].y = IMAGE_ROWS / 7;
    sampleBackPoints[3][1].x = IMAGE_COLS / 9 * 7.5 + SQUARE_LENGTH;
    sampleBackPoints[3][1].y = IMAGE_ROWS / 7 + SQUARE_LENGTH;
    sampleBackPoints[4][0].x = IMAGE_COLS / 9;
    sampleBackPoints[4][0].y = IMAGE_ROWS / 2.1;
    sampleBackPoints[4][1].x = IMAGE_COLS / 9 + SQUARE_LENGTH;
    sampleBackPoints[4][1].y = IMAGE_ROWS / 2.1 + SQUARE_LENGTH;
    sampleBackPoints[5][0].x = IMAGE_COLS / 3;
    sampleBackPoints[5][0].y = IMAGE_ROWS / 2.1;
    sampleBackPoints[5][1].x = IMAGE_COLS / 3+ SQUARE_LENGTH;
    sampleBackPoints[5][1].y = IMAGE_ROWS / 2.1 + SQUARE_LENGTH;
    sampleBackPoints[6][0].x = IMAGE_COLS / 1.7;
    sampleBackPoints[6][0].y = IMAGE_ROWS / 2.1;
    sampleBackPoints[6][1].x = IMAGE_COLS / 1.7 + SQUARE_LENGTH;
    sampleBackPoints[6][1].y = IMAGE_ROWS / 2.1 + SQUARE_LENGTH;
    sampleBackPoints[7][0].x = IMAGE_COLS / 9 * 7.5;
    sampleBackPoints[7][0].y = IMAGE_ROWS / 2.1;
    sampleBackPoints[7][1].x = IMAGE_COLS / 9 * 7.5 + SQUARE_LENGTH;
    sampleBackPoints[7][1].y = IMAGE_ROWS / 2.1  + SQUARE_LENGTH;
    sampleBackPoints[8][0].x = IMAGE_COLS / 9;
    sampleBackPoints[8][0].y = IMAGE_ROWS / 1.25;
    sampleBackPoints[8][1].x = IMAGE_COLS / 9 + SQUARE_LENGTH;
    sampleBackPoints[8][1].y = IMAGE_ROWS / 1.25 + SQUARE_LENGTH;
    sampleBackPoints[9][0].x = IMAGE_COLS / 3;
    sampleBackPoints[9][0].y = IMAGE_ROWS / 1.25;
    sampleBackPoints[9][1].x = IMAGE_COLS / 3 + SQUARE_LENGTH;
    sampleBackPoints[9][1].y = IMAGE_ROWS / 1.25+ SQUARE_LENGTH;
    sampleBackPoints[10][0].x = IMAGE_COLS / 1.7;
    sampleBackPoints[10][0].y = IMAGE_ROWS / 1.25;
    sampleBackPoints[10][1].x = IMAGE_COLS / 1.7 + SQUARE_LENGTH;
    sampleBackPoints[10][1].y = IMAGE_ROWS / 1.25 + SQUARE_LENGTH;
    sampleBackPoints[11][0].x = IMAGE_COLS / 9 * 7.5;
    sampleBackPoints[11][0].y = IMAGE_ROWS / 1.25;
    sampleBackPoints[11][1].x = IMAGE_COLS / 9 * 7.5 + SQUARE_LENGTH;
    sampleBackPoints[11][1].y = IMAGE_ROWS / 1.25 + SQUARE_LENGTH;
}
