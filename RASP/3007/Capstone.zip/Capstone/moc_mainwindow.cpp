/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Wed Jul 29 11:12:19 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   37,   37,   37, 0x08,
      38,   37,   37,   37, 0x08,
      73,   37,   37,   37, 0x08,
      87,  133,   37,   37, 0x08,
     138,   37,   37,   37, 0x08,
     165,   37,   37,   37, 0x08,
     191,   37,   37,   37, 0x08,
     215,   37,   37,   37, 0x08,
     241,   37,   37,   37, 0x08,
     265,   37,   37,   37, 0x08,
     288,   37,   37,   37, 0x08,
     310,   37,   37,   37, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0on_MainWindow_destroyed()\0"
    "\0onTranslatingResultChanged(double)\0"
    "onToShow(Mat)\0"
    "recceiveCroppedImage(Mat,Mat,Mat,Mat,QString)\0"
    ",,,,\0changeLabelNotice(QString)\0"
    "on_pushButton_5_clicked()\0"
    "on_btnTakepic_clicked()\0"
    "on_pushButton_6_clicked()\0"
    "changeToFrontHandMode()\0changeToBackHandMode()\0"
    "changeToBinaryImage()\0slotReboot()\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->on_MainWindow_destroyed(); break;
        case 1: _t->onTranslatingResultChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: _t->onToShow((*reinterpret_cast< Mat(*)>(_a[1]))); break;
        case 3: _t->recceiveCroppedImage((*reinterpret_cast< Mat(*)>(_a[1])),(*reinterpret_cast< Mat(*)>(_a[2])),(*reinterpret_cast< Mat(*)>(_a[3])),(*reinterpret_cast< Mat(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5]))); break;
        case 4: _t->changeLabelNotice((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->on_pushButton_5_clicked(); break;
        case 6: _t->on_btnTakepic_clicked(); break;
        case 7: _t->on_pushButton_6_clicked(); break;
        case 8: _t->changeToFrontHandMode(); break;
        case 9: _t->changeToBackHandMode(); break;
        case 10: _t->changeToBinaryImage(); break;
        case 11: _t->slotReboot(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
