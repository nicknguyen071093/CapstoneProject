/****************************************************************************
** Meta object code from reading C++ file 'TimerThread.h'
**
** Created: Wed Jul 29 11:13:16 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "TimerThread.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TimerThread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TimerThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   48,   48,   48, 0x05,
      49,   48,   74,   48, 0x05,
      79,   48,   48,   48, 0x05,
     114,   48,   48,   48, 0x05,
     148,   48,   48,   48, 0x05,
     178,   48,   48,   48, 0x05,
     207,   48,   48,   48, 0x05,

 // slots: signature, parameters, type, tag, flags
     246,   48,   48,   48, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_TimerThread[] = {
    "TimerThread\0sendSignalChangingToFrontHandMode()\0"
    "\0sendSignalToCheckFirst()\0bool\0"
    "sendSignalChangingToBackHandMode()\0"
    "sendSignalChangingToBinaryImage()\0"
    "sendSignalCheckingFrontHand()\0"
    "sendSignalCheckingBackHand()\0"
    "sendSignalChangingLabelNotice(QString)\0"
    "continueCountDown()\0"
};

void TimerThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TimerThread *_t = static_cast<TimerThread *>(_o);
        switch (_id) {
        case 0: _t->sendSignalChangingToFrontHandMode(); break;
        case 1: { bool _r = _t->sendSignalToCheckFirst();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: _t->sendSignalChangingToBackHandMode(); break;
        case 3: _t->sendSignalChangingToBinaryImage(); break;
        case 4: _t->sendSignalCheckingFrontHand(); break;
        case 5: _t->sendSignalCheckingBackHand(); break;
        case 6: _t->sendSignalChangingLabelNotice((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->continueCountDown(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData TimerThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject TimerThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_TimerThread,
      qt_meta_data_TimerThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &TimerThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *TimerThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *TimerThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TimerThread))
        return static_cast<void*>(const_cast< TimerThread*>(this));
    return QThread::qt_metacast(_clname);
}

int TimerThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void TimerThread::sendSignalChangingToFrontHandMode()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
bool TimerThread::sendSignalToCheckFirst()
{
    bool _t0;
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
    return _t0;
}

// SIGNAL 2
void TimerThread::sendSignalChangingToBackHandMode()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void TimerThread::sendSignalChangingToBinaryImage()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void TimerThread::sendSignalCheckingFrontHand()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void TimerThread::sendSignalCheckingBackHand()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void TimerThread::sendSignalChangingLabelNotice(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_END_MOC_NAMESPACE
